{-|
Module      : IR
Description : Intermediate Representation

The modified AST that is ready to be used for code generation.
-}
module Banana.TypeCheck.IR where
