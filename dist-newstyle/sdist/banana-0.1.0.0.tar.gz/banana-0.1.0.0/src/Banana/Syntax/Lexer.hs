{-|
Module      : Lexer
Description : Tokenizer

The lexer is responsible for taking the source code as a string
  and cutting it into tokens.
-}
module Banana.Syntax.Lexer where
