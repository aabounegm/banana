module Banana.CodeGen.LLVMSpec (spec) where

import           Test.Hspec

spec :: Spec
spec = do
  describe "CodeGen" $ do
    it "" $ do
      pendingWith "Not yet implemented"
