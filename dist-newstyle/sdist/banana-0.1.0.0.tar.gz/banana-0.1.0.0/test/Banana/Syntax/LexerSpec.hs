module Banana.Syntax.LexerSpec (spec) where

import           Test.Hspec

spec :: Spec
spec = do
  describe "Lexer" $ do
    it "" $ do
      pendingWith "Decide if we need a lexer"
