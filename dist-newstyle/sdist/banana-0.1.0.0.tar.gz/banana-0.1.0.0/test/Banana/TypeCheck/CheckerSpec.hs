module Banana.TypeCheck.CheckerSpec (spec) where

import           Test.Hspec

spec :: Spec
spec = do
  describe "TypeCheck" $ do
    it "" $ do
      pendingWith "Not yet implemented"
